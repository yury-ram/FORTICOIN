# 🤝 Contributing to Forticoin

We welcome contributions from the community!  
Whether it's reporting a bug, suggesting a feature, or submitting a pull request — your help is valuable.

## How to contribute

1. **Fork** the repository  
2. **Create a branch** for your feature or fix:  
   ```bash
   git checkout -b feature-name
   ```
3. **Commit your changes**:  
   ```bash
   git commit -m "Add feature X"
   ```
4. **Push to your branch**:  
   ```bash
   git push origin feature-name
   ```
5. Open a **Pull Request** 🎉

---

## Reporting Issues
- Use the **Issues** tab on GitHub.  
- Describe the problem clearly.  
- Include steps to reproduce if it’s a bug.  

---

## Code of Conduct
By contributing, you agree to follow our Code of Conduct (coming soon).
