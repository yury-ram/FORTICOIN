<p align="center">
  <img src="assets/logo.png" alt="Forticoin Logo" width="300"/>
</p>

# Forticoin

**Forticoin** is an innovative token that combines a **base asset** (Bitcoin, Ethereum, or others) with a **put option** on the same asset and in the same volume.  
It is designed to minimize risks while preserving upside potential, making long-term cryptocurrency investments more secure and predictable.

![License](https://img.shields.io/badge/license-Apache%202.0-blue.svg)
![Build](https://img.shields.io/badge/status-in%20development-orange)

---

## 📖 Concept

The project aims to create a token that includes both a cryptocurrency (e.g., Bitcoin, Ethereum) and a **put option** on the same asset.  
The expiration date of the option depends on the token type, allowing investors to choose the most suitable product.  

### Example  
On **September 1, 2025**, an investor buys **1 BTC** at $109,000 and simultaneously buys a **put option** with a strike price of $110,000 for $13,600, expiring on **June 26, 2026**.  
As a result, the investor receives **1 FORTICOIN** (1 BTC + 1 put option) worth **$122,600** at a BTC price of $109,000.  

#### Two scenarios:  
1. **BTC falls to $80,000** → 1 FORTICOIN ≈ **$95,400 – $95,700**, depending on the option’s premium.  
2. **BTC rises** → 1 FORTICOIN = BTC price + residual option value (depends on price and time to expiration).  

Closing a position (or part of it) is possible at any time without restrictions.  

---

## 💡 Why Forticoin?

- **Investment**: safer long-term crypto investments with minimized downside risk.  
- **DeFi**: great tool for medium/long-term loans without liquidation risks.  
- **Payments**: predictable payments in volatile markets (for work, goods, or services).  

---

## 📈 Market Potential  

The crypto options market is only beginning to develop.  
With Forticoin and similar tools, more people will invest, use DeFi, and plan their financial future with crypto instruments.  

---

## 🛤 Roadmap
See [ROADMAP.md](ROADMAP.md) for details.

---

## 🤝 Contribution
We welcome contributions! Please check [CONTRIBUTING.md](CONTRIBUTING.md) for guidelines.

---

## 📜 License
This project is licensed under the **Apache License 2.0** – see the [LICENSE](LICENSE) file for details.
